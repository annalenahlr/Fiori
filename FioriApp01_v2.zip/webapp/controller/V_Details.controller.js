sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
	"use strict";
	return Controller.extend("sappi.com.FioriApp01_v2.controller.V_Details", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf sappi.com.FioriApp01_v2.view.V_Details
		 */
		onInit: function () {
			// Get the Router Info
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			
			// Validate/Match the Router Details sent from source using oRouter.navTo("Router_Detail", {SelectedItem: selectPO});
			oRouter.getRoute("Route_Details").attachMatched(this._onRouteFound, this);

		},
		
		_onRouteFound: function(oEvt) {

			var oArgument = oEvt.getParameter("arguments");
			
			var oView = this.getView();
			
			oView.bindElement({
			path: "/A_BusinessPartner('" + oArgument.SelectedItem + "')"
			});
		},
		/**
		 *@memberOf sappi.com.FioriApp01_v2.controller.V_Details
		 */
		onGoBack: function (oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			
			oRouter.navTo("Route_Overview", {});
		}
	});
});