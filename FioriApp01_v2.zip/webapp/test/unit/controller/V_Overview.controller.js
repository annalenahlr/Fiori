/*global QUnit*/

sap.ui.define([
	"sappi/com/FioriApp01_v2/controller/V_Overview.controller"
], function (Controller) {
	"use strict";

	QUnit.module("V_Overview Controller");

	QUnit.test("I should test the V_Overview controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});